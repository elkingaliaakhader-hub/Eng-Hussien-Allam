import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomeHero } from './components/HomeHero';
import { VideoPlayerView } from './components/VideoPlayerView';
import { ForumView } from './components/ForumView';
import { StudentDashboardView } from './components/StudentDashboardView';
import { TeacherGate } from './components/TeacherGate';
import { TeacherDashboard } from './components/TeacherDashboard';
import { StudentLoginModal } from './components/StudentLoginModal';
import { GlassPhysicsBackground } from './components/GlassPhysicsBackground';

import { 
  Lesson, 
  StudentCode, 
  StudentUser, 
  ForumPost, 
  ForumAnswer, 
  PlatformNotification 
} from './types';

import {
  getStoredLessons,
  saveLessons,
  getStoredCodes,
  saveCodes,
  getStoredStudents,
  saveStudents,
  getStoredForum,
  saveForum,
  getStoredNotifications,
  saveNotifications,
  getCurrentStudent,
  saveCurrentStudent,
  isTeacherAuthenticated,
  setTeacherAuthenticated
} from './services/store';

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Core Data State
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [selectedLessonId, setSelectedLessonId] = useState<string>('');
  const [codes, setCodes] = useState<StudentCode[]>([]);
  const [students, setStudents] = useState<StudentUser[]>([]);
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([]);
  const [notifications, setNotifications] = useState<PlatformNotification[]>([]);

  // Auth State
  const [currentStudent, setCurrentStudent] = useState<StudentUser | null>(null);
  const [isTeacherAuth, setIsTeacherAuth] = useState<boolean>(false);
  const [showStudentLoginModal, setShowStudentLoginModal] = useState<boolean>(false);

  // Toast / Live Alert
  const [liveToast, setLiveToast] = useState<string | null>(null);

  // Initialize data on mount
  useEffect(() => {
    const loadedLessons = getStoredLessons();
    const loadedCodes = getStoredCodes();
    const loadedStudents = getStoredStudents();
    const loadedForum = getStoredForum();
    const loadedNotifs = getStoredNotifications();
    const loadedStudent = getCurrentStudent();
    const teacherAuth = isTeacherAuthenticated();

    setLessons(loadedLessons);
    if (loadedLessons.length > 0) {
      if (loadedStudent) {
        const studentLesson = loadedLessons.find(l => l.grade === loadedStudent.grade);
        setSelectedLessonId(studentLesson ? studentLesson.id : loadedLessons[0].id);
      } else {
        setSelectedLessonId(loadedLessons[0].id);
      }
    }
    setCodes(loadedCodes);
    setStudents(loadedStudents);
    setForumPosts(loadedForum);
    setNotifications(loadedNotifs);
    setCurrentStudent(loadedStudent);
    setIsTeacherAuth(teacherAuth);
  }, []);

  // Update HTML dark class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Handle Live Toast Timer
  useEffect(() => {
    if (!liveToast) return;
    const timer = setTimeout(() => setLiveToast(null), 5000);
    return () => clearTimeout(timer);
  }, [liveToast]);

  // --------------------------------------------------------------------------
  // ACTIONS: LESSONS
  // --------------------------------------------------------------------------
  const handleAddLesson = (newLesson: Lesson) => {
    const updated = [newLesson, ...lessons];
    setLessons(updated);
    saveLessons(updated);
    setSelectedLessonId(newLesson.id);

    // Push notification to all students
    const notif: PlatformNotification = {
      id: 'notif-' + Date.now(),
      title: 'محاضرة جديدة أُضيفت للتو! 🚀',
      body: `نشر المهندس حسين علام: "${newLesson.title}" (${newLesson.grade} - ${newLesson.unit})`,
      time: 'الآن',
      type: 'lesson',
      read: false
    };
    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    saveNotifications(updatedNotifs);

    setLiveToast(`📢 تم نشر المحاضرة "${newLesson.title}" ووصل إشعار فوري لجميع الطلاب!`);
  };

  const handleDeleteLesson = (id: string) => {
    const updated = lessons.filter(l => l.id !== id);
    setLessons(updated);
    saveLessons(updated);
    if (selectedLessonId === id && updated.length > 0) {
      setSelectedLessonId(updated[0].id);
    }
  };

  // --------------------------------------------------------------------------
  // ACTIONS: CODES & STUDENT REGISTRATION
  // --------------------------------------------------------------------------
  const handleAddCode = (newCode: StudentCode) => {
    const updated = [newCode, ...codes];
    setCodes(updated);
    saveCodes(updated);

    const notif: PlatformNotification = {
      id: 'notif-' + Date.now(),
      title: 'تم إصدار كود طالب جديد 🔑',
      body: `الكود: ${newCode.code} - ${newCode.grade} جاهز لمشاركته مع الطالب.`,
      time: 'الآن',
      type: 'code',
      read: false
    };
    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    saveNotifications(updatedNotifs);
  };

  const handleRevokeCode = (codeStr: string) => {
    const updated = codes.map(c => c.code === codeStr ? { ...c, status: 'revoked' as const } : c);
    setCodes(updated);
    saveCodes(updated);
  };

  const handleDeleteCode = (codeStr: string) => {
    const updated = codes.filter(c => c.code !== codeStr);
    setCodes(updated);
    saveCodes(updated);
  };

  const handleStudentLoginSuccess = (student: StudentUser) => {
    setCurrentStudent(student);
    saveCurrentStudent(student);

    // 1. Mark code as used
    const updatedCodes = codes.map(c => {
      if (c.code.toUpperCase() === student.codeUsed.toUpperCase()) {
        const nextTimesUsed = c.timesUsed + 1;
        const usedByList = c.usedBy || [];
        return {
          ...c,
          timesUsed: nextTimesUsed,
          status: (nextTimesUsed >= c.maxUses ? 'used' : 'active') as 'used' | 'active',
          usedBy: [
            ...usedByList,
            {
              studentName: student.name,
              studentPhone: student.phone,
              usedAt: student.registeredAt
            }
          ]
        };
      }
      return c;
    });
    setCodes(updatedCodes);
    saveCodes(updatedCodes);

    // 2. Add / Update student in live attendance log so teacher sees it!
    const existingIndex = students.findIndex(s => s.phone === student.phone);
    let updatedStudents: StudentUser[];
    if (existingIndex >= 0) {
      updatedStudents = [...students];
      updatedStudents[existingIndex] = {
        ...updatedStudents[existingIndex],
        lastLoginAt: 'الآن',
        status: 'online',
        codeUsed: student.codeUsed,
        grade: student.grade
      };
    } else {
      updatedStudents = [student, ...students];
    }
    setStudents(updatedStudents);
    saveStudents(updatedStudents);

    // 3. Auto-select first lecture matching student's grade and switch to lessons tab
    const gradeMatching = lessons.find(l => l.grade === student.grade);
    if (gradeMatching) {
      setSelectedLessonId(gradeMatching.id);
    }
    setActiveTab('lessons');

    const gradeLabel = student.grade === '1ث' ? 'الصف الأول الثانوي' : student.grade === '2ث' ? 'الصف الثاني الثانوي' : 'الصف الثالث الثانوي';
    setLiveToast(`مرحباً يا بطل ${student.name}! تم فتح محاضرات ${gradeLabel} وتفعيل المشغل لحسابك 🚀`);
  };

  const handleLogoutStudent = () => {
    if (currentStudent) {
      const updatedStudents = students.map(s => 
        s.phone === currentStudent.phone ? { ...s, status: 'offline' as const, lastLoginAt: 'منذ لحظات' } : s
      );
      setStudents(updatedStudents);
      saveStudents(updatedStudents);
    }
    setCurrentStudent(null);
    saveCurrentStudent(null);
    setLiveToast('تم تسجيل الخروج بنجاح.');
  };

  // --------------------------------------------------------------------------
  // ACTIONS: TEACHER AUTH
  // --------------------------------------------------------------------------
  const handleTeacherUnlock = () => {
    setIsTeacherAuth(true);
    setTeacherAuthenticated(true);
    setLiveToast('أهلاً بك يا مهندس حسين علام! تم تسجيل الدخول بنجاح إلى لوحة التحكم.');
  };

  const handleTeacherLogout = () => {
    setIsTeacherAuth(false);
    setTeacherAuthenticated(false);
    setActiveTab('home');
    setLiveToast('تم تسجيل خروج المدرس.');
  };

  // --------------------------------------------------------------------------
  // ACTIONS: FORUM
  // --------------------------------------------------------------------------
  const handleAddForumPost = (post: ForumPost) => {
    const updated = [post, ...forumPosts];
    setForumPosts(updated);
    saveForum(updated);

    const notif: PlatformNotification = {
      id: 'notif-' + Date.now(),
      title: 'سؤال جديد في المنتدى 💬',
      body: `طرح ${post.authorName}: "${post.title}" في قسم ${post.category}.`,
      time: 'الآن',
      type: 'forum',
      read: false
    };
    const updatedNotifs = [notif, ...notifications];
    setNotifications(updatedNotifs);
    saveNotifications(updatedNotifs);

    setLiveToast('تم نشر سؤالك في المنتدى بنجاح! سيتم إشعار المهندس حسين علام وزملائك.');
  };

  const handleAddForumAnswer = (postId: string, answer: ForumAnswer) => {
    const updated = forumPosts.map(p => {
      if (p.id === postId) {
        return {
          ...p,
          answers: [...p.answers, answer]
        };
      }
      return p;
    });
    setForumPosts(updated);
    saveForum(updated);

    if (answer.isTeacherVerified) {
      const targetPost = forumPosts.find(p => p.id === postId);
      const notif: PlatformNotification = {
        id: 'notif-' + Date.now(),
        title: 'رد معتمد من المهندس حسين علام! ⭐',
        body: `أجاب المدرس على السؤال: "${targetPost?.title || 'سؤال في المنتدى'}".`,
        time: 'الآن',
        type: 'forum',
        read: false
      };
      const updatedNotifs = [notif, ...notifications];
      setNotifications(updatedNotifs);
      saveNotifications(updatedNotifs);
      setLiveToast('تم اعتماد ونشر رد المدرس في المنتدى.');
    } else {
      setLiveToast('تمت إضافة إجابتك بنجاح.');
    }
  };

  const handleUpvotePost = (postId: string) => {
    const updated = forumPosts.map(p => {
      if (p.id === postId) {
        return { ...p, upvotes: p.upvotes + 1 };
      }
      return p;
    });
    setForumPosts(updated);
    saveForum(updated);
  };

  // --------------------------------------------------------------------------
  // ACTIONS: QUIZ SCORE & PROGRESS
  // --------------------------------------------------------------------------
  const handleSaveQuizScore = (lessonId: string, score: number, total: number) => {
    if (!currentStudent) return;
    const lessonObj = lessons.find(l => l.id === lessonId);
    const title = lessonObj?.title || 'اختبار فيزياء';

    const newScoreItem = {
      lessonId,
      lessonTitle: title,
      score,
      total,
      date: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
    };

    const updatedStudent: StudentUser = {
      ...currentStudent,
      quizScores: [newScoreItem, ...currentStudent.quizScores.filter(qs => qs.lessonId !== lessonId)]
    };

    setCurrentStudent(updatedStudent);
    saveCurrentStudent(updatedStudent);

    // Update in students log
    const updatedStudents = students.map(s => s.id === updatedStudent.id ? updatedStudent : s);
    setStudents(updatedStudents);
    saveStudents(updatedStudents);

    setLiveToast(`أحسنت! تم حفظ نتيجتك (${score}/${total}) في سجل إنجازك.`);
  };

  const handleMarkLessonCompleted = (lessonId: string) => {
    if (!currentStudent) return;
    if (currentStudent.completedLessonIds.includes(lessonId)) return;

    const updatedStudent: StudentUser = {
      ...currentStudent,
      completedLessonIds: [...currentStudent.completedLessonIds, lessonId]
    };
    setCurrentStudent(updatedStudent);
    saveCurrentStudent(updatedStudent);

    const updatedStudents = students.map(s => s.id === updatedStudent.id ? updatedStudent : s);
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
  };

  const handleMarkNotificationRead = (id: string) => {
    const updated = notifications.map(n => n.id === id ? { ...n, read: true } : n);
    setNotifications(updated);
    saveNotifications(updated);
  };

  const activeLesson = lessons.find(l => l.id === selectedLessonId) || (lessons.length > 0 ? lessons[0] : null);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden">
      
      {/* Floating Glassy Physics Apparatus & Orbits Background */}
      <GlassPhysicsBackground />

      {/* Toast Notification Alert */}
      {liveToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 max-w-md w-full px-4 animate-in slide-in-from-top-4 duration-300">
          <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold p-4 rounded-2xl shadow-2xl flex items-center justify-between text-xs sm:text-sm">
            <span>{liveToast}</span>
            <button 
              onClick={() => setLiveToast(null)} 
              className="mr-2 text-slate-950/70 hover:text-slate-950 font-black text-lg"
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Main Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentStudent={currentStudent}
        onOpenStudentLogin={() => setShowStudentLoginModal(true)}
        onLogoutStudent={handleLogoutStudent}
        isTeacherAuth={isTeacherAuth}
        onLogoutTeacher={handleTeacherLogout}
        notifications={notifications}
        onMarkNotificationRead={handleMarkNotificationRead}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Content Area */}
      <main className="flex-1 relative z-10">
        {activeTab === 'home' && (
          <HomeHero
            onOpenLessons={() => setActiveTab('lessons')}
            onOpenLoginModal={() => setShowStudentLoginModal(true)}
            onOpenTeacherGate={() => setActiveTab('teacher')}
            onOpenForum={() => setActiveTab('forum')}
            onSelectLesson={(id) => {
              setSelectedLessonId(id);
              setActiveTab('lessons');
            }}
            lessons={lessons}
            currentStudent={currentStudent}
          />
        )}

        {activeTab === 'lessons' && (
          <VideoPlayerView
            lesson={activeLesson}
            allLessons={lessons}
            onSelectLesson={(id) => setSelectedLessonId(id)}
            currentStudent={currentStudent}
            onOpenLoginModal={() => setShowStudentLoginModal(true)}
            onSaveQuizScore={handleSaveQuizScore}
            onMarkLessonCompleted={handleMarkLessonCompleted}
            onOpenTeacherUpload={() => setActiveTab('teacher')}
          />
        )}

        {activeTab === 'forum' && (
          <ForumView
            posts={forumPosts}
            onAddPost={handleAddForumPost}
            onAddAnswer={handleAddForumAnswer}
            onUpvotePost={handleUpvotePost}
            currentStudent={currentStudent}
            isTeacherAuth={isTeacherAuth}
            onOpenLoginModal={() => setShowStudentLoginModal(true)}
          />
        )}

        {activeTab === 'dashboard' && (
          <StudentDashboardView
            currentStudent={currentStudent}
            lessons={lessons}
            onSelectLesson={(id) => {
              setSelectedLessonId(id);
              setActiveTab('lessons');
            }}
            onOpenLoginModal={() => setShowStudentLoginModal(true)}
          />
        )}

        {activeTab === 'teacher' && (
          isTeacherAuth ? (
            <TeacherDashboard
              lessons={lessons}
              onAddLesson={handleAddLesson}
              onDeleteLesson={handleDeleteLesson}
              codes={codes}
              onAddCode={handleAddCode}
              onRevokeCode={handleRevokeCode}
              onDeleteCode={handleDeleteCode}
              students={students}
              forumPosts={forumPosts}
              onTeacherReply={(postId, text) => {
                const answer: ForumAnswer = {
                  id: 'ans-' + Date.now(),
                  authorName: 'المهندس حسين علام',
                  authorRole: 'teacher',
                  isTeacherVerified: true,
                  content: text,
                  createdAt: 'الآن',
                  upvotes: 0
                };
                handleAddForumAnswer(postId, answer);
              }}
              onLogout={handleTeacherLogout}
              onSelectLessonForPreview={(id) => {
                setSelectedLessonId(id);
                setActiveTab('lessons');
              }}
            />
          ) : (
            <TeacherGate
              onUnlock={handleTeacherUnlock}
              onCancel={() => setActiveTab('home')}
            />
          )
        )}
      </main>

      {/* Student Code Login Modal */}
      <StudentLoginModal
        isOpen={showStudentLoginModal}
        onClose={() => setShowStudentLoginModal(false)}
        availableCodes={codes}
        onLoginSuccess={handleStudentLoginSuccess}
      />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-12 px-4 sm:px-6 lg:px-8 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-right space-y-1">
            <span className="font-display font-black text-white text-sm block">
              منصة المهندس حسين علام للفيزياء © 2026
            </span>
            <p>الثانوية العامة والأزهر والبكالوريا · شرح هندسي وفهم فيزيائي متكامل</p>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-medium">
            <button onClick={() => setActiveTab('home')} className="hover:text-amber-400 transition">
              الرئيسية
            </button>
            <span>·</span>
            <button onClick={() => setActiveTab('lessons')} className="hover:text-amber-400 transition">
              مشغل الدروس
            </button>
            <span>·</span>
            <button onClick={() => setActiveTab('forum')} className="hover:text-amber-400 transition">
              منتدى النقاشات
            </button>
            <span>·</span>
            <button onClick={() => setActiveTab('dashboard')} className="hover:text-amber-400 transition">
              لوحة الطالب
            </button>
            <span>·</span>
            <button onClick={() => setActiveTab('teacher')} className="text-amber-400 hover:text-amber-300 font-bold transition">
              بوابة المدرس
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
