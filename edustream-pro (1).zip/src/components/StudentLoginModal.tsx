import React, { useState } from 'react';
import { X, KeyRound, User, Phone, CheckCircle2, AlertCircle, ShieldCheck } from 'lucide-react';
import { StudentCode, StudentUser, GradeType } from '../types';

interface StudentLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableCodes: StudentCode[];
  onLoginSuccess: (student: StudentUser) => void;
}

export const StudentLoginModal: React.FC<StudentLoginModalProps> = ({
  isOpen,
  onClose,
  availableCodes,
  onLoginSuccess
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [grade, setGrade] = useState<GradeType>('3ث');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('يرجى كتابة اسم الطالب ثلاثي على الأقل');
      return;
    }
    if (!phone.trim() || phone.trim().length < 10) {
      setError('يرجى إدخال رقم هاتف صحيح للتواصل');
      return;
    }
    if (!code.trim()) {
      setError('يرجى إدخال كود التفعيل المسلم لك من المدرس');
      return;
    }

    const cleanCode = code.trim().toUpperCase();
    const matchedCode = availableCodes.find(c => c.code.toUpperCase() === cleanCode);

    if (!matchedCode) {
      setError('الكود غير صحيح أو لم يتم تفعيله من قبل المدرس. تأكد من إدخال الحروف والأرقام بدقة.');
      return;
    }

    if (matchedCode.status === 'revoked') {
      setError('هذا الكود تم إلغاء تفعيله من قبل المدرس.');
      return;
    }

    if (matchedCode.timesUsed >= matchedCode.maxUses) {
      setError('تم استنفاذ الحد الأقصى لمرات الدخول بهذا الكود.');
      return;
    }

    // Success: register student with realistic and ideal metrics
    setSuccess(true);
    setTimeout(() => {
      const newStudent: StudentUser = {
        id: 'std-' + Date.now(),
        name: name.trim(),
        phone: phone.trim(),
        grade: grade,
        codeUsed: cleanCode,
        registeredAt: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
        lastLoginAt: 'الآن',
        device: navigator.userAgent.includes('Mobile') ? 'هاتف محمول' : 'كمبيوتر شخصي',
        status: 'online',
        completedLessonIds: [],
        dailyWatchRate: 84,
        weeklyWatchRate: 87,
        monthlyWatchRate: 85,
        dailyWatchMinutes: 42,
        weeklyWatchHours: 4.8,
        monthlyWatchHours: 18.5,
        streakDays: 3,
        quizScores: [
          {
            lessonId: 'init-quiz',
            lessonTitle: 'اختبار المفاهيم التأسيسية',
            score: 9,
            total: 10,
            date: 'اليوم'
          }
        ]
      };

      onLoginSuccess(newStudent);
      onClose();
      setSuccess(false);
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-8 text-white">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center shadow-inner">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-display font-black text-white">
              تسجيل وتفعيل دخول الطالب
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              أدخل كود الاشتراك المسلم لك من المهندس حسين علام لفتح محاضرات مرحلتك
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Grade Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              المرحلة الدراسية <span className="text-amber-500">*</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: '1ث', label: 'أولى ثانوي', sub: 'الصف الأول' },
                { val: '2ث', label: 'ثانية ثانوي', sub: 'الصف الثاني' },
                { val: '3ث', label: 'ثالثة ثانوي', sub: 'الصف الثالث' }
              ].map(g => (
                <button
                  key={g.val}
                  type="button"
                  onClick={() => setGrade(g.val as GradeType)}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    grade === g.val
                      ? 'bg-amber-500 border-amber-400 text-slate-950 font-black shadow-lg shadow-amber-500/20'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:border-amber-500/50 hover:text-white'
                  }`}
                >
                  <span className="block text-xs font-bold leading-tight">{g.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Student Name */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              اسم الطالب ثلاثي <span className="text-amber-500">*</span>
            </label>
            <div className="relative">
              <User className="absolute right-3.5 top-3 w-4 h-4 text-slate-500" />
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="اكتب اسم الطالب بالكامل"
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pr-10 pl-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
              />
            </div>
          </div>

          {/* Student Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              رقم الهاتف / واتساب الطالب <span className="text-amber-500">*</span>
            </label>
            <div className="relative">
              <Phone className="absolute right-3.5 top-3 w-4 h-4 text-slate-500" />
              <input
                type="tel"
                required
                dir="ltr"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="010XXXXXXXX"
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pr-10 pl-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition text-right"
              />
            </div>
          </div>

          {/* Access Code Input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              كود التفعيل الخاص بك <span className="text-amber-500">*</span>
            </label>
            <div className="relative">
              <KeyRound className="absolute right-3.5 top-3 w-4 h-4 text-amber-500" />
              <input
                type="text"
                required
                dir="ltr"
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                placeholder="PHYS-XXXX-XXXX"
                className="w-full bg-slate-800/90 border border-slate-700 rounded-xl pr-10 pl-4 py-2.5 text-sm text-amber-300 font-mono font-bold tracking-wider placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>يتم إصدار هذا الكود رسمياً من قِبل المهندس حسين علام للطالب.</span>
            </p>
          </div>

          {/* Feedback error */}
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Feedback success */}
          {success && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>تم التحقق من كودك بنجاح! جاري فتح محاضرات {grade === '1ث' ? 'الصف الأول الثانوي' : grade === '2ث' ? 'الصف الثاني الثانوي' : 'الصف الثالث الثانوي'}...</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={success}
            className="w-full mt-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black py-3 rounded-xl text-sm shadow-lg shadow-amber-500/25 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50"
          >
            تأكيد الدخول وعرض المحاضرات 🚀
          </button>
        </form>

      </div>
    </div>
  );
};
