import { Lesson, StudentCode, StudentUser, ForumPost, PlatformNotification } from '../types';

// High-reliability video URLs that play smoothly across all devices and browsers without CORS issues
// YouTube embed URLs provide 100% reliable streaming inside iframes, complete with player controls & HD resolution
const VIDEO_STREAMS = {
  // 3rd Secondary: Electricity & Ohm's Law (Physics lecture embed)
  electricity: 'https://www.youtube-nocookie.com/embed/aircAruvnKk',
  // 3rd Secondary: Magnetism & Electromagnetic Induction
  magnetism: 'https://www.youtube-nocookie.com/embed/8b_tF3gMvB8',
  // 3rd Secondary: Modern Physics & Quantum Theory
  modern: 'https://www.youtube-nocookie.com/embed/Q_h4IoPJXZw',
  // 2nd Secondary: Wave Motion & Optics
  waves: 'https://www.youtube-nocookie.com/embed/TdQx3B4q4f8',
  // 1st Secondary: Physics Measurement, Dimensional Analysis & Motion
  motion: 'https://www.youtube-nocookie.com/embed/ZM8ECpBuQYE',
  // Direct MP4 fallback stream (Mozilla MDN CC0 verified stream)
  mp4Fallback: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4'
};

export const INITIAL_LESSONS: Lesson[] = [
  // =========================================================================
  // الصف الثالث الثانوي (3ث) - 3rd Secondary
  // =========================================================================
  {
    id: 'lesson-3sec-1',
    title: 'قانون أوم للدائرة المغلقة والمقاومة النوعية وتوصيل المقاومات',
    grade: '3ث',
    chapter: 'الفصل الأول: التيار الكهربي وقانون أوم وكيرشوف',
    unit: 'الوحدة الأولى: الفيزياء الكهربية',
    duration: '48:30 دقيقة',
    description: 'شرح هندسي وفيزيائي متكامل لقانون أوم للدائرة المغلقة V = VB - Ir، وحساب القوة الدافعة الكهربية للبطارية، والمقاومة النوعية والتوصيلية الكهربية مع حل 8 مسائل من امتحانات الثانوية العامة السابقة.',
    videoUrl: VIDEO_STREAMS.electricity,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'شيت_قانون_أوم_الدائرة_المغلقة_المهندس_حسين_علام.pdf',
    pdfSize: '3.4 ميجابايت',
    publishedAt: '2026-10-18',
    viewsCount: 384,
    attachments: [
      {
        id: 'att-1',
        name: 'مذكرة قوانين الفصل الأول (خريطة ذهنية كاملة).pdf',
        url: '#',
        size: '2.1 ميجابايت',
        type: 'pdf'
      },
      {
        id: 'att-2',
        name: 'شيت 40 مسألة على توصيل المقاومات وتوزيع الجهد.pdf',
        url: '#',
        size: '1.8 ميجابايت',
        type: 'pdf'
      }
    ],
    keyPoints: [
      'فرق الجهد بين قطبي العمود: V = VB - Ir عند التفريغ، و V = VB + Ir عند الشحن.',
      'تزداد كفاءة البطارية كلما قلت مقاومتها الداخلية r واقتربت من الصفر.',
      'عند غلق المفتاح يزداد تيار الدائرة الكلي ويزداد الهبوط في الجهد (Ir) فيقل فرق الجهد الخارجي V.',
      'المقاومة النوعية ρe خاصية فيزيائية مميزة للمادة تعتمد فقط على نوع المادة ودرجة الحرارة.'
    ],
    quiz: [
      {
        id: 'q1-1',
        question: 'عمود كهربي قوته الدافعة 12V ومقاومته الداخلية 2Ω، وُصل بمقاومة خارجية 4Ω. ما هي قراءة الفولتميتر بين قطبي العمود؟',
        options: ['12 فولت', '8 فولت', '4 فولت', '10 فولت'],
        correctIndex: 1,
        explanation: 'التيار الكلي I = VB / (R + r) = 12 / (4 + 2) = 2 A. قراءة الفولتميتر V = VB - Ir = 12 - (2 × 2) = 8 V.'
      },
      {
        id: 'q1-2',
        question: 'إذا زاد طول سلك موصل للضعف وقَلّت مساحة مقطعه للنصف، فإن مقاومته الكهربية:',
        options: ['تزداد للضعف', 'تزداد لـ 4 أمثالها', 'تظل ثابتة', 'تقل للربع'],
        correctIndex: 1,
        explanation: 'R = ρe × L / A. بمضاعفة L (×2) وتقليل A (÷2)، تصبح المقاومة الجديدة 2 / 0.5 = 4 أمثال قيمتها الأولى.'
      },
      {
        id: 'q1-3',
        question: 'عند فتح الدائرة الكهربية، يكون فرق الجهد بين قطبي البطارية مساوياً لـ:',
        options: ['الصفر', 'القوة الدافعة الكهربية VB', 'نصف القوة الدافعة', 'مالانهاية'],
        correctIndex: 1,
        explanation: 'عند فتح الدائرة ينعدم التيار I = 0، وبالتالي الهبوط في الجهد Ir = 0، فتصبح V = VB تماماً.'
      }
    ]
  },
  {
    id: 'lesson-3sec-2',
    title: 'الحث الكهرومغناطيسي، قاعدة لنز ومولد التيار المتردد (الدينامو)',
    grade: '3ث',
    chapter: 'الفصل الثالث: الحث الكهرومغناطيسي',
    unit: 'الوحدة الأولى: الفيزياء الكهربية',
    duration: '54:15 دقيقة',
    description: 'تحليل دقيق لقانون فاراداي وقاعدة لنز وقوة لورنتز. استنتاج القوة الدافعة الكهربية اللحظية والعظمى والفعالة في ملف الدينامو مع توضيح الزوايا الحرجة وطريقة رسم المنحنى الجيبي.',
    videoUrl: VIDEO_STREAMS.magnetism,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'ملزمة_الحث_وقوانين_الدينامو_المهندس_حسين_علام.pdf',
    pdfSize: '4.2 ميجابايت',
    publishedAt: '2026-10-17',
    viewsCount: 295,
    attachments: [
      {
        id: 'att-3',
        name: 'مخطط زوايا الدينامو (العمودي على الملف والمجال).pdf',
        url: '#',
        size: '1.5 ميجابايت',
        type: 'pdf'
      }
    ],
    keyPoints: [
      'emf = -N (ΔΦm / Δt) الإشارة السالبة تعبر عن قاعدة لنز (المعارضة).',
      'في الدينامو: emf اللحظية = NABω sin θ، حيث θ هي الزاوية بين العمودي على مستوى الملف والمجال.',
      'القيمة الفعالة: emf eff = 0.707 × emf max = emf max / √2.',
      'الطاقة والقدرة المستهلكة في المقاومة تُحسب دائماً بالقيم الفعالة فقط.'
    ],
    quiz: [
      {
        id: 'q2-1',
        question: 'متى تكون القوة الدافعة الكهربية المستحثة في ملف الدينامو قيمة عظمى؟',
        options: [
          'عندما يكون مستوى الملف موازياً للمجال المغناطيسي',
          'عندما يكون مستوى الملف عمودياً على المجال',
          'عندما يصنع مستوى الملف زاوية 45 درجة',
          'عند انعدام خطوط الفيض المغناطيسي'
        ],
        correctIndex: 0,
        explanation: 'عندما يكون الملف موازياً للمجال، يكون العمودي عليه عمودياً على المجال (θ = 90°)، فتكون sin 90° = 1 وتصل emf لقيمتها العظمى NABω.'
      }
    ]
  },
  {
    id: 'lesson-3sec-3',
    title: 'ازدواجية الموجة والجسيم وإشعاع الجسم الأسود وظاهرة كومتون',
    grade: '3ث',
    chapter: 'الفصل الخامس: مقدمة في الفيزياء الحديثة',
    unit: 'الوحدة الثانية: الفيزياء الحديثة',
    duration: '42:00 دقيقة',
    description: 'مدخل الفيزياء الكلاسيكية والحديثة، تفسير ماكس بلانك لكَمّات الطاقة والفوتونات، قانون فين، إثبات الصفة الجسيمية للإشعاع الكهرومغناطيسي من خلال ظاهرة كومتون والظاهرة الكهروضوئية.',
    videoUrl: VIDEO_STREAMS.modern,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'الفيزياء_الحديثة_الفصل_الخامس_ملخص_المهندس_حسين_علام.pdf',
    pdfSize: '3.9 ميجابايت',
    publishedAt: '2026-10-15',
    viewsCount: 210,
    keyPoints: [
      'طاقة الفوتون E = hν = hc / λ، وتتناسب طردياً مع التردد وعكسياً مع الطول الموجي.',
      'قانون فين: الطول الموجي المصاحب لأقصى شدة إشعاع يتناسب عكسياً مع درجة الحرارة الكلفنية T.',
      'ظاهرة كومتون تثبت أن للفوتون كمية حركة (P = h / λ) وكتلة مكافئة (m = hν / c²).'
    ],
    quiz: [
      {
        id: 'q3-1',
        question: 'في ظاهرة كومتون، بعد التصادم بين فوتون أشعة إكس وإلكترون حر، أي من التالي يقل للفوتون؟',
        options: ['سرعته', 'طوله الموجي', 'تردده وطاقته', 'كتلته السكونية'],
        correctIndex: 2,
        explanation: 'الفوتون يعطي جزءاً من طاقته للإلكترون، فيقل تردده وطاقته ويزداد طوله الموجي، بينما تظل سرعته ثابتة مساوية لسرعة الضوء c.'
      }
    ]
  },

  // =========================================================================
  // الصف الثاني الثانوي (2ث) - 2nd Secondary
  // =========================================================================
  {
    id: 'lesson-2sec-1',
    title: 'الحركة الموجية وخواص الموجات الطولية والمستعرضة والسرعة والتردد',
    grade: '2ث',
    chapter: 'الفصل الأول: الحركة الموجية',
    unit: 'الوحدة الأولى: الموجات والضوء',
    duration: '45:10 دقيقة',
    description: 'شرح مفاهيم الاهتزازة الكاملة، سعة الاهتزاز، الزمن الدوري والتردد، والفرق بين الموجات الكهرومغناطيسية والميكانيكية، وقانون انتشار الموجات v = λ × ν مع تطبيقات وتمارين كتاب المدرسة.',
    videoUrl: VIDEO_STREAMS.waves,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'مذكرة_الحركة_الموجية_2ث_المهندس_حسين_علام.pdf',
    pdfSize: '2.8 ميجابايت',
    publishedAt: '2026-10-18',
    viewsCount: 165,
    keyPoints: [
      'العلاقة بين التردد والزمن الدوري علاقة عكسية: ν = 1 / T.',
      'سرعة انتشار الموجة في نفس الوسط ثابتة، وتتغير فقط عند الانتقال من وسط لآخر.',
      'الموجات المستعرضة تتكون من قمم وقيعان وتتحرك جزيئات الوسط عمودياً على اتجاه الانتشار.'
    ],
    quiz: [
      {
        id: 'q2s-1',
        question: 'إذا انتقلت موجة ضوئية من الهواء إلى الزجاج، فإن الخاصية التي لا تتغير هي:',
        options: ['سرعة الموجة', 'التردد', 'الطول الموجي', 'السعة'],
        correctIndex: 1,
        explanation: 'التردد يعتمد على مصدر الموجة فقط ولا يتغير عند انتقال الموجة بين أوساط مختلفة.'
      }
    ]
  },
  {
    id: 'lesson-2sec-2',
    title: 'انكسار الضوء والانعكاس الكلي والزاوية الحرجة والمنشور الثلاثي',
    grade: '2ث',
    chapter: 'الفصل الثاني: الضوء وخواصه',
    unit: 'الوحدة الأولى: الموجات والضوء',
    duration: '50:20 دقيقة',
    description: 'قانون سنل، معامل الانكسار المطلق والنسبي، شروط حدوث الانعكاس الكلي واستخدام الألياف الضوئية، وتتبع مسار شعاع ضوئي داخل منشور ثلاثي وحساب زاوية الانحراف الصغرى.',
    videoUrl: VIDEO_STREAMS.waves,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'شيت_انكسار_الضوء_والمنشور_2ث_المهندس_حسين_علام.pdf',
    pdfSize: '3.1 ميجابايت',
    publishedAt: '2026-10-16',
    viewsCount: 142,
    keyPoints: [
      'قانون سنل: n1 sin φ = n2 sin θ.',
      'الزاوية الحرجة sin φc = 1 / n، وتحدث عندما ينتقل الضوء من وسط أكبر كثافة ضوئية لوسط أقل.',
      'في المنشور: زاوية الرأس A = θ1 + φ2، وزاوية الانحراف α = φ1 + θ2 - A.'
    ],
    quiz: [
      {
        id: 'q2s-2',
        question: 'الشرط الأساسي لحدوث الانعكاس الكلي للضوء هو أن يسقط الشعاع من وسط:',
        options: [
          'أقل كثافة ضوئية إلى أكبر كثافة بزاوية أكبر من الحرجة',
          'أكبر كثافة ضوئية إلى أقل كثافة بزاوية أكبر من الحرجة',
          'بزاوية سقوط تساوي صفر دائماً',
          'متساوي في الكثافة الضوئية مع الوسط الثاني'
        ],
        correctIndex: 1,
        explanation: 'يحدث الانعكاس الكلي فقط عند الانتقال من وسط أكبر كثافة (معامل انكساره أكبر) إلى وسط أقل كثافة وبزاوية سقوط تتجاوز الزاوية الحرجة.'
      }
    ]
  },

  // =========================================================================
  // الصف الأول الثانوي (1ث) - 1st Secondary
  // =========================================================================
  {
    id: 'lesson-1sec-1',
    title: 'القياس الفيزيائي، صيغ الأبعاد ومعادلات التحقق والخطأ في القياس',
    grade: '1ث',
    chapter: 'الفصل الأول: القياس الفيزيائي',
    unit: 'الوحدة الأولى: الكميات الفيزيائية ووحدات القياس',
    duration: '40:45 دقيقة',
    description: 'أساسيات الفيزياء: الكميات الأساسية والمشتقة، صيغ الأبعاد [M] [L] [T]، كيفية التحقق من صحة القوانين الفيزيائية، والخطأ المطلق والخطأ النسبي وحساب نسبة الخطأ المئوية.',
    videoUrl: VIDEO_STREAMS.motion,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'مذكرة_صيغ_الأبعاد_1ث_المهندس_حسين_علام.pdf',
    pdfSize: '2.5 ميجابايت',
    publishedAt: '2026-10-18',
    viewsCount: 198,
    keyPoints: [
      'صيغة أبعاد السرعة: [L T⁻¹]، وصيغة أبعاد العجلة: [L T⁻²].',
      'صيغة أبعاد القوة: [M L T⁻²]، وصيغة أبعاد الشغل والطاقة: [M L² T⁻²].',
      'الخطأ النسبي r = Δx / x₀ هو الأدق في الحكم على دقة عملية القياس.'
    ],
    quiz: [
      {
        id: 'q1s-1',
        question: 'إذا كانت صيغة أبعاد كمية فيزيائية هي [M L² T⁻²] فإن هذه الكمية تمثل:',
        options: ['السرعة', 'القوة', 'الشغل أو طاقة الحركة', 'الضغط'],
        correctIndex: 2,
        explanation: 'الشغل = القوة × الإزاحة = [M L T⁻²] × [L] = [M L² T⁻²].'
      }
    ]
  },
  {
    id: 'lesson-1sec-2',
    title: 'الحركة في خط مستقيم بعجلة منتظمة ومعادلات الحركة الثلاث',
    grade: '1ث',
    chapter: 'الفصل الثاني: الحركة والسرعة والعجلة',
    unit: 'الوحدة الثانية: الحركة الخطية',
    duration: '46:30 دقيقة',
    description: 'شرح شامل لمعادلات الحركة بعجلة منتظمة: vf = vi + at ، d = vi t + ½ at² ، vf² = vi² + 2ad مع حل مسائل المقذوفات الرأسية والسقوط الحر وعجلة الجاذبية الأرضية.',
    videoUrl: VIDEO_STREAMS.motion,
    backupVideoUrl: VIDEO_STREAMS.mp4Fallback,
    downloadUrl: VIDEO_STREAMS.mp4Fallback,
    pdfName: 'شيت_معادلات_الحركة_والسقوط_الحر_1ث.pdf',
    pdfSize: '2.9 ميجابايت',
    publishedAt: '2026-10-16',
    viewsCount: 176,
    keyPoints: [
      'المعادلة الأولى: vf = vi + at (تربط السرعة بالزمن).',
      'المعادلة الثانية: d = vi t + ½ at² (تربط الإزاحة بالزمن).',
      'المعادلة الثالثة: vf² = vi² + 2ad (تربط السرعة بالإزاحة دون زمن).',
      'في السقوط الحر من السكون: vi = 0 والعجلة a = +g (موجبة).'
    ],
    quiz: [
      {
        id: 'q1s-2',
        question: 'سقط جسم سقوطاً حراً من أعلى مبنى فوصل للأرض بعد 3 ثوانٍ (بفرض g = 10 m/s²). فإن ارتفاع المبنى يساوي:',
        options: ['30 متراً', '45 متراً', '90 متراً', '15 متراً'],
        correctIndex: 1,
        explanation: 'سقوط حر vi = 0. نطبق المعادلة الثانية: d = vi t + ½ g t² = 0 + ½ (10) (3)² = 5 × 9 = 45 متراً.'
      }
    ]
  }
];

export const INITIAL_STUDENT_CODES: StudentCode[] = [
  // 3rd Secondary Codes (3ث)
  {
    code: 'PHYS-3SEC-2026',
    grade: '3ث',
    maxUses: 10,
    timesUsed: 1,
    status: 'active',
    createdAt: '2026-10-19',
    note: 'كود طلاب الصف الثالث الثانوي - سنتر المهندسين',
    usedBy: [
      {
        studentName: 'محمد أحمد فهمي',
        studentPhone: '01011223344',
        usedAt: '2026-10-19 11:20 ص'
      }
    ]
  },
  {
    code: 'ALLAM-3SEC-9142',
    grade: '3ث',
    maxUses: 5,
    timesUsed: 0,
    status: 'active',
    createdAt: '2026-10-19',
    note: 'كود اشتراك شهر أكتوبر - 3 ثانوي'
  },

  // 2nd Secondary Codes (2ث)
  {
    code: 'PHYS-2SEC-6614',
    grade: '2ث',
    maxUses: 10,
    timesUsed: 1,
    status: 'active',
    createdAt: '2026-10-18',
    note: 'كود طلاب الصف الثاني الثانوي',
    usedBy: [
      {
        studentName: 'محمود طارق',
        studentPhone: '01155667788',
        usedAt: '2026-10-18 05:40 م'
      }
    ]
  },

  // 1st Secondary Codes (1ث)
  {
    code: 'PHYS-1SEC-8820',
    grade: '1ث',
    maxUses: 10,
    timesUsed: 1,
    status: 'active',
    createdAt: '2026-10-18',
    note: 'كود طلاب الصف الأول الثانوي',
    usedBy: [
      {
        studentName: 'يوسف حسام الدين',
        studentPhone: '01299887766',
        usedAt: '2026-10-18 03:15 م'
      }
    ]
  },

  // All Grades General Code
  {
    code: 'PHYS-VIP-ALLAM',
    grade: 'جميع الصفوف',
    maxUses: 100,
    timesUsed: 6,
    status: 'active',
    createdAt: '2026-10-17',
    note: 'كود اشتراك شامل لجميع المراحل'
  }
];

export const INITIAL_STUDENT_LOGINS: StudentUser[] = [];

export const INITIAL_FORUM_POSTS: ForumPost[] = [
  {
    id: 'forum-1',
    title: 'إزاي أفرق بين اتجاه التيار المستحث وقاعدة فيلمنج لليد اليمنى وقاعدة لنز؟',
    content: 'يا باشمهندس دايماً بتلخبط في أسئلة الامتحان لما يطلب اتجاه التيار المستحث: إمتى أطبق فيلمنج لليد اليمنى وإمتى أطبق قاعدة لنز؟ وممكن مثال يوضح الفرق؟',
    authorName: 'أحمد محمد محمود',
    authorRole: 'student',
    grade: '3ث',
    category: 'الحث الكهرومغناطيسي',
    createdAt: 'منذ ساعتين',
    upvotes: 18,
    answers: [
      {
        id: 'ans-1',
        authorName: 'المهندس حسين علام',
        authorRole: 'teacher',
        isTeacherVerified: true,
        content: 'أهلاً يا بطل! سؤال ممتاز ومهم جداً:\n\n1) قاعدة فيلمنج لليد اليمنى: تُستخدم فقط عندما يتحرك "سلك مستقيم" داخل مجال مغناطيسي منتظم ليقطع خطوط الفيض (emf = -BLv sinθ). اجعل الإبهام مع الحركة والسبابة مع المجال، فيشير الوسطى لاتجاه التيار المستحث.\n\n2) قاعدة لنز: تُستخدم في "الملفات" (دائرية أو حلزونية). المبدأ هو المعارضة: لو القطب المغناطيسي بيقرب من الملف، الملف يولد قطباً مشابهاً ليتنافر معه، ولو بيبتعد الملف يولد قطباً مخالفاً ليتجاذب معه. ثم تحدد اتجاه التيار باستخدام اليد اليمنى لأمبير أو عقارب الساعة.\n\nلو حفظت المقارنة دي، مفيش سؤال هيقف قدامك بإذن الله!',
        createdAt: 'منذ ساعة',
        upvotes: 24
      }
    ]
  },
  {
    id: 'forum-2',
    title: 'سؤال لطلاب 1 ثانوي: إمتى العجلة تكون سالبة حتى لو الجسم بيتحرك للأمام؟',
    content: 'في معادلات الحركة بعجلة منتظمة، هل الإشارة السالبة تعني إن الجسم بيرجع لورا؟ ولا تعني تباطؤ؟',
    authorName: 'خالد سليم',
    authorRole: 'student',
    grade: '1ث',
    category: 'الحركة والسرعة',
    createdAt: 'منذ 4 ساعات',
    upvotes: 11,
    answers: [
      {
        id: 'ans-2',
        authorName: 'المهندس حسين علام',
        authorRole: 'teacher',
        isTeacherVerified: true,
        content: 'سؤال رائع يا خالد! الإشارة السالبة للعجلة تعني أن اتجاه العجلة عكس اتجاه السرعة، أي أن سرعة الجسم تتناقص بمرور الزمن (تباطؤ) مثل الضغط على الفرامل، وليس معناه أنه يتحرك للخلف. الجسم يظل يتحرك للأمام ولكن بسرعة متناقصة حتى يسكن لحظياً.',
        createdAt: 'منذ 3 ساعات',
        upvotes: 15
      }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: PlatformNotification[] = [
  {
    id: 'notif-welcome',
    title: 'أهلاً بك في منصة المهندس حسين علام! ⚛️',
    body: 'تم تنظيم المحاضرات حسب مرحلتك الدراسية (أولى، ثانية، ثالثة ثانوي) مع نسب إنجاز واقعية.',
    time: 'الآن',
    type: 'system',
    read: false
  }
];
